/* =====================================================================
   Serveur : stockage dans le Google Sheet qui contient ce script.
   ===================================================================== */

// Nom des onglets du Google Sheet
var ONGLETS = {
  classes: "Classes", eleves: "Élèves", matieres: "Matières", regles: "Règles",
  ponctuels: "Séances ponctuelles", annulations: "Annulations",
  inscriptions: "Inscriptions", journal: "Journal", reglages: "Réglages", ouvertures: "Ouvertures manuelles",
  fermetures: "Fermetures", archives: "Archives inscriptions"
};
var ECRITURE = { reserver: 1, annuler: 1, verifier: 1, gestion: 1 };

/* Cache : une copie des onglets en mémoire chez Google (CacheService), bien plus rapide que la lecture du Sheet.
   Il n'est rempli que par une requête qui tient le verrou : personne ne peut écrire en même temps,
   donc la copie est toujours identique au Sheet. Une modification faite à la main dans le Sheet vide le cache (onEdit). */
var CACHE_P = "colloscope-v1:", CACHE_DUREE = 21600, CACHE_MORCEAU = 25000, FIN_JOURNAL = 2000;
function cache_() { try { return CacheService.getScriptCache(); } catch (e) { return null; } }
function cacheLire_(c, cle) {
  if (!c) return null;
  try {
    var n = c.get(CACHE_P + cle);
    if (n === null) return null;
    n = Number(n); if (!n) return [];
    var cles = []; for (var i = 0; i < n; i++) cles.push(CACHE_P + cle + ":" + i);
    var parts = c.getAll(cles), s = "";
    for (var j = 0; j < cles.length; j++) { if (parts[cles[j]] == null) return null; s += parts[cles[j]]; }
    return JSON.parse(s);
  } catch (e) { return null; }
}
function cacheEcrire_(c, cle, rows) {
  if (!c) return;
  try {
    var s = JSON.stringify(rows), o = {}, n = 0;
    for (var i = 0; i < s.length; i += CACHE_MORCEAU) o[CACHE_P + cle + ":" + (n++)] = s.substr(i, CACHE_MORCEAU);
    o[CACHE_P + cle] = String(n);
    c.putAll(o, CACHE_DUREE);
  } catch (e) { cacheOublier_(c, [cle]); }
}
function cacheOublier_(c, cles) {
  if (!c) return;
  try { c.removeAll(cles.map(function (k) { return CACHE_P + k; })); } catch (e) {}
}
function viderCache_() {
  var cles = [];
  Object.keys(ONGLETS).forEach(function (n) { cles.push(n, n + "~fin"); });
  cacheOublier_(cache_(), cles);
}
// Modification à la main dans le Google Sheet : le site la voit tout de suite.
function onEdit() { viderCache_(); }
// Menu « Colloscope » dans le Google Sheet (utile après une suppression de lignes, qui ne déclenche pas onEdit).
function onOpen() {
  SpreadsheetApp.getUi().createMenu("Colloscope").addItem("Mettre à jour le site avec le Sheet", "viderCache").addToUi();
}
function viderCache() { viderCache_(); SpreadsheetApp.getActiveSpreadsheet().toast("C'est fait : le site affiche maintenant le contenu du Sheet."); }

function store_(verrou) {
  var ss = SpreadsheetApp.getActiveSpreadsheet(), c = cache_();
  // Lecture : un onglet absent = tableau vide (on ne crée rien pendant une simple lecture).
  function trouver(nom) { return ss.getSheetByName(ONGLETS[nom]); }
  // Écriture : crée l'onglet si besoin ; si deux requêtes le créent en même temps, on récupère l'existant.
  function onglet(nom, cols) {
    var sh = trouver(nom);
    if (!sh) {
      try { sh = ss.insertSheet(ONGLETS[nom]); } catch (e) { sh = trouver(nom); if (!sh) throw e; }
      sh.setFrozenRows(1);
    }
    // L'en-tête est réécrit à chaque écriture : il reste aligné avec les colonnes si le code évolue.
    sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight("bold");
    return sh;
  }
  function objets(head, rows) {
    return rows.filter(function (r) { return r.join("") !== ""; })
      .map(function (r) { var o = {}; head.forEach(function (k, i) { o[k] = r[i]; }); return o; });
  }
  function lireTout(nom) {
    var sh = trouver(nom);
    if (!sh || sh.getLastRow() < 2) return [];
    var v = sh.getDataRange().getDisplayValues();
    return objets(v[0], v.slice(1));
  }
  function lireFin(nom, n) {
    var sh = trouver(nom);
    if (!sh || sh.getLastRow() < 2) return [];
    var der = sh.getLastRow(), premiere = Math.max(2, der - n + 1);
    var head = sh.getRange(1, 1, 1, sh.getLastColumn()).getDisplayValues()[0];
    return objets(head, sh.getRange(premiere, 1, der - premiere + 1, head.length).getDisplayValues());
  }
  // Lecture depuis le Sheet ; la copie en cache n'est faite que sous verrou (voir plus haut).
  function lireEtCacher(cle, lire) {
    if (verrou) { var r = lire(); cacheEcrire_(c, cle, r); return r; }
    var l = null;
    try { l = LockService.getScriptLock(); if (!l.tryLock(0)) l = null; } catch (e) { l = null; }
    if (!l) return lire();
    try { var r2 = lire(); cacheEcrire_(c, cle, r2); return r2; } finally { l.releaseLock(); }
  }
  return {
    load: function (nom) {
      var r = cacheLire_(c, nom);
      return r || lireEtCacher(nom, function () { return lireTout(nom); });
    },
    // Les n dernières lignes seulement (journal)
    loadTail: function (nom, n) {
      if (n > FIN_JOURNAL) return lireFin(nom, n);
      var r = cacheLire_(c, nom + "~fin");
      if (!r) r = lireEtCacher(nom + "~fin", function () { return lireFin(nom, FIN_JOURNAL); });
      return r.slice(-n);
    },
    // Écrit d'abord les nouvelles lignes, puis efface seulement ce qui dépasse :
    // une lecture simultanée ne voit jamais l'onglet vide.
    save: function (nom, rows) {
      var cols = COLLES.TABLES[nom];
      cacheOublier_(c, [nom, nom + "~fin"]);
      var sh = onglet(nom, cols);
      var avant = Math.max(0, sh.getLastRow() - 1);
      if (rows.length) sh.getRange(2, 1, rows.length, cols.length).setNumberFormat("@").setValues(lignes_(cols, rows));
      if (avant > rows.length) sh.getRange(2 + rows.length, 1, avant - rows.length, Math.max(cols.length, sh.getLastColumn())).clearContent();
      if (verrou) cacheEcrire_(c, nom, rows.map(function (o) { var x = {}; cols.forEach(function (k) { x[k] = o[k] === undefined ? "" : String(o[k]); }); return x; }));
    },
    append: function (nom, rows) {
      if (!rows.length) return;
      var cols = COLLES.TABLES[nom];
      var fin = verrou ? cacheLire_(c, nom + "~fin") : null;
      cacheOublier_(c, [nom, nom + "~fin"]);
      var sh = onglet(nom, cols);
      sh.getRange(sh.getLastRow() + 1, 1, rows.length, cols.length).setNumberFormat("@").setValues(lignes_(cols, rows));
      if (fin) cacheEcrire_(c, nom + "~fin", fin.concat(rows.map(function (o) { var x = {}; cols.forEach(function (k) { x[k] = o[k] === undefined ? "" : String(o[k]); }); return x; })).slice(-FIN_JOURNAL));
    }
  };
}

function lignes_(cols, rows) {
  return rows.map(function (o) { return cols.map(function (k) { return o[k] === undefined ? "" : String(o[k]); }); });
}

function maintenant_() {
  var d = new Date(), tz = "Europe/Paris";
  return {
    date: Utilities.formatDate(d, tz, "yyyy-MM-dd"),
    time: Utilities.formatDate(d, tz, "HH:mm"),
    iso: Utilities.formatDate(d, tz, "yyyy-MM-dd'T'HH:mm:ss")
  };
}

function repondre_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var p;
  try { p = JSON.parse(e.postData.contents); } catch (err) { p = null; }
  if (!p || typeof p !== "object") return repondre_({ ok: false, error: "Requête illisible." });
  var lock = null;
  if (ECRITURE[p.action]) {
    // Les écritures passent une par une : deux élèves ne peuvent pas prendre la même dernière place.
    lock = LockService.getScriptLock();
    if (!lock.tryLock(25000)) return repondre_({ ok: false, error: "Beaucoup de monde en même temps : réessaie dans quelques secondes." });
  }
  try {
    return repondre_(COLLES.traiter(store_(!!lock), p, maintenant_()));
  } catch (err) {
    console.error(err);
    return repondre_({ ok: false, error: "Erreur du serveur. Réessaie plus tard." });
  } finally {
    if (lock) lock.releaseLock();
  }
}

// Adresse ouverte par le bouton « Calendrier Apple » : renvoie le fichier agenda de la colle.
function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action === "ics") {
    try {
      var r = COLLES.traiter(store_(false), { action: "ics", c: p.c, app: p.app }, maintenant_());
      if (r.ok) return ContentService.createTextOutput(r.ics).setMimeType(ContentService.MimeType.ICAL);
      return ContentService.createTextOutput(r.error);
    } catch (err) {
      console.error(err);
      return ContentService.createTextOutput("Erreur du serveur. Réessaie plus tard.");
    }
  }
  return repondre_({ ok: true, message: "Serveur des colles en ligne." });
}

/* À lancer UNE fois après avoir collé ce code (bouton « Exécuter »). */
function installer() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss.getSheetByName(ONGLETS.classes)) throw new Error("Déjà installé : supprimez les onglets pour recommencer.");
  var code = function (n) {
    var c = "ABCDEFGHJKMNPQRSTUVWXYZ23456789", s = "";
    for (var i = 0; i < n; i++) s += c.charAt(Math.floor(Math.random() * c.length));
    return s;
  };
  var codes = { admin: code(10), acces: code(6) };
  COLLES.depart().matieres.forEach(function (m) { codes[m.id] = code(8); });
  viderCache_();
  var data = COLLES.depart(codes), st = store_(false);
  Object.keys(COLLES.TABLES).forEach(function (t) { st.save(t, data[t] || []); });
  var sh = ss.getSheetByName("Codes") || ss.insertSheet("Codes", 0);
  var lignes = [["Codes créés à l'installation (s'ils sont changés ensuite sur le site, cette liste n'est plus à jour)", ""],
    ["Code administrateur (à garder pour toi)", codes.admin],
    ["Code d'accès des élèves (le même pour toute la prépa)", codes.acces], ["", ""]];
  data.matieres.forEach(function (m) {
    var c = data.classes.filter(function (x) { return x.id === m.classe; })[0];
    lignes.push(["Code de gestion " + m.nom + ", " + c.nom, m.code]);
  });
  lignes.push(["", ""], ["Étape suivante : ajoute les listes d'élèves depuis le site (Espace gestion > Administration > Élèves).", ""],
    ["Vacances et jours fériés : onglet « Fermetures » (une ligne par période, dates au format AAAA-MM-JJ).", ""],
    ["Les codes se modifient depuis l'espace gestion, onglet Administration.", ""],
    ["Un même code peut ouvrir plusieurs matières : donnez-leur le même code.", ""]);
  sh.getRange(1, 1, lignes.length, 2).setValues(lignes);
  sh.autoResizeColumns(1, 2);
}
