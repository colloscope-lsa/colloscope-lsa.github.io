/* =====================================================================
   Serveur : stockage dans le Google Sheet qui contient ce script.
   ===================================================================== */

// Nom des onglets du Google Sheet
var ONGLETS = {
  classes: "Classes", eleves: "Élèves", matieres: "Matières", regles: "Règles",
  ponctuels: "Séances ponctuelles", annulations: "Annulations",
  inscriptions: "Inscriptions", journal: "Journal", reglages: "Réglages", ouvertures: "Ouvertures manuelles",
  fermetures: "Fermetures", archives: "Archives inscriptions", avis: "Alertes élèves"
};
var ECRITURE = { reserver: 1, annuler: 1, verifier: 1, gestion: 1 };

/* Rapidité : une copie des onglets est gardée en mémoire chez Google (CacheService).
   - Une requête lit toute la copie en UN appel ; le Google Sheet n'est ouvert que pour écrire.
   - La copie n'est remplie que par une requête qui tient le verrou : personne ne peut écrire en même temps,
     donc elle est toujours identique au Sheet.
   - Une modification faite à la main dans le Sheet efface la copie (onEdit, ou le menu Colloscope).
   - Le journal et les archives ne sont jamais relus côté élève : ils restent seulement dans le Sheet. */
var CACHE_P = "colloscope-v2:", CACHE_DUREE = 21600, CACHE_MORCEAU = 25000, CACHE_MAX = 8;
var CACHE_RAFRAICHIR = 5 * 3600 * 1000;   // au-delà, une simple lecture recharge la copie depuis le Sheet
function enCache_(nom) { return nom !== "journal" && nom !== "archives"; }
function cache_() { try { return CacheService.getScriptCache(); } catch (e) { return null; } }
function cacheOublier_(c, noms, entetes) {
  if (!c || !noms.length) return;
  var cles = [];
  noms.forEach(function (n) { cles.push(CACHE_P + n); if (entetes) cles.push(CACHE_P + "entete~" + n); });
  try { c.removeAll(cles); } catch (e) {}
}
function viderCache_() { cacheOublier_(cache_(), Object.keys(ONGLETS), true); }
// Modification à la main dans le Google Sheet : le site la voit tout de suite.
function onEdit() { viderCache_(); }
// Menu « Colloscope » dans le Google Sheet (utile après une suppression de lignes, qui ne déclenche pas onEdit).
function onOpen() {
  SpreadsheetApp.getUi().createMenu("Colloscope").addItem("Mettre à jour le site avec le Sheet", "viderCache").addToUi();
}
function viderCache() { viderCache_(); SpreadsheetApp.getActiveSpreadsheet().toast("C'est fait : le site affiche maintenant le contenu du Sheet."); }

function store_(verrou) {
  var ss = null, c = cache_(), pre = null, tiens = false, lock = null;
  var aEcrire = [], aCacher = {}, entetesOk = {};
  function classeur() { return ss || (ss = SpreadsheetApp.getActiveSpreadsheet()); }
  function trouver(nom) { return classeur().getSheetByName(ONGLETS[nom]); }
  function objets(head, rows) {
    return rows.filter(function (r) { return r.join("") !== ""; })
      .map(function (r) { var o = {}; head.forEach(function (k, i) { o[k] = r[i]; }); return o; });
  }
  // Lecture d'un onglet : un onglet absent = tableau vide (on ne crée rien pendant une lecture).
  function lireFeuille(nom) {
    var sh = trouver(nom);
    if (!sh) return [];
    var v = sh.getDataRange().getDisplayValues();
    return v.length < 2 ? [] : objets(v[0], v.slice(1));
  }
  function lireFin(nom, n) {
    var sh = trouver(nom);
    if (!sh || sh.getLastRow() < 2) return [];
    var der = sh.getLastRow(), premiere = Math.max(2, der - n + 1);
    var head = sh.getRange(1, 1, 1, sh.getLastColumn()).getDisplayValues()[0];
    return objets(head, sh.getRange(premiere, 1, der - premiere + 1, head.length).getDisplayValues());
  }
  // Toute la copie en un seul appel
  function prechargement() {
    if (pre) return pre;
    pre = {};
    if (!c) return pre;
    var cles = [];
    Object.keys(ONGLETS).forEach(function (n) {
      cles.push(CACHE_P + "entete~" + n);
      if (!enCache_(n)) return;
      cles.push(CACHE_P + n);
      for (var i = 0; i < CACHE_MAX; i++) cles.push(CACHE_P + n + ":" + i);
    });
    try { pre = c.getAll(cles) || {}; } catch (e) { pre = {}; }
    return pre;
  }
  function depuisCache(nom) {
    var p = prechargement(), meta;
    try { meta = JSON.parse(p[CACHE_P + nom]); } catch (e) { return null; }
    if (!meta || typeof meta.n !== "number") return null;
    var s = "";
    for (var i = 0; i < meta.n; i++) {
      var k = CACHE_P + nom + ":" + i, part = p[k];
      if (part == null && i >= CACHE_MAX) { try { part = c.get(k); } catch (e) { part = null; } }
      if (part == null) return null;
      s += part;
    }
    try { return { rows: JSON.parse(s), le: meta.le }; } catch (e) { return null; }
  }
  // Pour remplir la copie, il faut le verrou (déjà pris par une écriture, sinon on tente sans attendre).
  function verrouille() {
    if (verrou || tiens) return true;
    if (!c) return false;
    try { lock = LockService.getScriptLock(); tiens = lock.tryLock(0); } catch (e) { tiens = false; }
    return tiens;
  }
  function aCopier(nom, rows) {
    var cols = COLLES.TABLES[nom];
    aCacher[nom] = rows.map(function (o) { var x = {}; cols.forEach(function (k) { x[k] = o[k] === undefined ? "" : String(o[k]); }); return x; });
  }
  return {
    load: function (nom) {
      if (!enCache_(nom)) return lireFeuille(nom);
      var x = depuisCache(nom);
      // Copie récente : on s'en sert. Copie ancienne : une lecture la recharge si elle peut prendre le verrou.
      if (x && (verrou || !(Date.now() - (x.le || 0) > CACHE_RAFRAICHIR) || !verrouille())) return x.rows;
      var ok = verrouille();   // le verrou AVANT de lire : aucune écriture ne peut se glisser entre la lecture et la copie
      var rows = lireFeuille(nom);
      if (ok) aCopier(nom, rows);
      return rows;
    },
    // Les n dernières lignes seulement (journal, espace gestion)
    loadTail: function (nom, n) { return lireFin(nom, n); },
    // Les écritures sont regroupées et faites ensemble à la fin (terminer)
    save: function (nom, rows) { aEcrire.push({ nom: nom, rows: rows, tout: true }); },
    append: function (nom, rows) { if (rows.length) aEcrire.push({ nom: nom, rows: rows, tout: false }); },
    terminer: function () {
      try {
        if (aEcrire.length) {
          var noms = [];
          aEcrire.forEach(function (o) { if (noms.indexOf(o.nom) < 0) noms.push(o.nom); });
          // 1. La copie des tableaux modifiés est d'abord oubliée
          cacheOublier_(c, noms.filter(enCache_));
          var p = prechargement();
          // 2. Toutes les lectures avant toute écriture : Google envoie ensuite les écritures en une fois
          var prep = aEcrire.map(function (o) {
            var cols = COLLES.TABLES[o.nom], sh = trouver(o.nom), cree = false;
            if (!sh) {
              try { sh = classeur().insertSheet(ONGLETS[o.nom]); cree = true; } catch (e) { sh = trouver(o.nom); if (!sh) throw e; }
              sh.setFrozenRows(1);
            }
            var x = { o: o, cols: cols, sh: sh, der: cree ? 1 : sh.getLastRow(), cree: cree, larg: cols.length };
            if (o.tout && x.der - 1 > o.rows.length) x.larg = Math.max(cols.length, sh.getLastColumn());
            x.entete = !cree && p[CACHE_P + "entete~" + o.nom] === cols.join("|");
            return x;
          });
          // 3. Écritures (texte brut, pour que Google ne transforme pas les dates et les heures)
          prep.forEach(function (x) {
            var o = x.o, cols = x.cols, sh = x.sh;
            // En-tête réécrit de temps en temps : il reste aligné avec les colonnes si le code évolue.
            if (!x.entete) { sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight("bold"); entetesOk[o.nom] = cols.join("|"); }
            if (o.tout) {
              // Nouvelles lignes d'abord, puis on efface seulement ce qui dépasse : l'onglet n'est jamais vide.
              if (o.rows.length) sh.getRange(2, 1, o.rows.length, cols.length).setNumberFormat("@").setValues(lignes_(cols, o.rows));
              if (x.der - 1 > o.rows.length) sh.getRange(2 + o.rows.length, 1, x.der - 1 - o.rows.length, x.larg).clearContent();
              x.der = 1 + o.rows.length;
            } else {
              sh.getRange(x.der + 1, 1, o.rows.length, cols.length).setNumberFormat("@").setValues(lignes_(cols, o.rows));
              x.der += o.rows.length;
            }
          });
          SpreadsheetApp.flush();
          // 4. Nouvelle copie des tableaux réécrits en entier
          if (verrou) aEcrire.forEach(function (o) { if (enCache_(o.nom)) { if (o.tout) aCopier(o.nom, o.rows); else delete aCacher[o.nom]; } });
          aEcrire = [];
        }
        // 5. Une seule mise en cache pour toute la requête
        if (c && (verrou || tiens)) {
          var obj = {}, n = 0, maintenant = Date.now();
          Object.keys(aCacher).forEach(function (nom) {
            var s = JSON.stringify(aCacher[nom]), k = 0;
            for (var i = 0; i < s.length; i += CACHE_MORCEAU) obj[CACHE_P + nom + ":" + (k++)] = s.substr(i, CACHE_MORCEAU);
            obj[CACHE_P + nom] = JSON.stringify({ n: k, le: maintenant }); n++;
          });
          Object.keys(entetesOk).forEach(function (nom) { obj[CACHE_P + "entete~" + nom] = entetesOk[nom]; n++; });
          if (n) { try { c.putAll(obj, CACHE_DUREE); } catch (e) { cacheOublier_(c, Object.keys(aCacher)); } }
        }
        aCacher = {}; entetesOk = {};
      } finally { this.liberer(); }
    },
    liberer: function () { if (tiens && lock) { try { lock.releaseLock(); } catch (e) {} } tiens = false; }
  };
}

function lignes_(cols, rows) {
  return rows.map(function (o) { return cols.map(function (k) { return o[k] === undefined ? "" : String(o[k]); }); });
}

function maintenant_() {
  var d = new Date(), tz = "Europe/Paris";
  return {
    date: Utilities.formatDate(d, tz, "yyyy-MM-dd"),
    time: Utilities.formatDate(d, tz, "HH:mm"),
    iso: Utilities.formatDate(d, tz, "yyyy-MM-dd'T'HH:mm:ss")
  };
}

function repondre_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var p;
  try { p = JSON.parse(e.postData.contents); } catch (err) { p = null; }
  if (!p || typeof p !== "object") return repondre_({ ok: false, error: "Requête illisible." });
  var lock = null;
  if (ECRITURE[p.action]) {
    // Les écritures passent une par une : deux élèves ne peuvent pas prendre la même dernière place.
    lock = LockService.getScriptLock();
    if (!lock.tryLock(25000)) return repondre_({ ok: false, error: "Beaucoup de monde en même temps : réessaie dans quelques secondes." });
  }
  var st = null;
  try {
    st = store_(!!lock);
    var r = COLLES.traiter(st, p, maintenant_());
    st.terminer();
    return repondre_(r);
  } catch (err) {
    console.error(err);
    return repondre_({ ok: false, error: "Erreur du serveur. Réessaie plus tard." });
  } finally {
    if (st) st.liberer();
    if (lock) lock.releaseLock();
  }
}

// Fichier agenda d'une colle à une adresse directe (le site télécharge maintenant le fichier lui-même).
function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action === "ics") {
    var st = null;
    try {
      st = store_(false);
      var r = COLLES.traiter(st, { action: "ics", c: p.c, app: p.app }, maintenant_());
      st.terminer();
      if (r.ok) return ContentService.createTextOutput(r.ics).setMimeType(ContentService.MimeType.ICAL);
      return ContentService.createTextOutput(r.error);
    } catch (err) {
      console.error(err);
      return ContentService.createTextOutput("Erreur du serveur. Réessaie plus tard.");
    } finally {
      if (st) st.liberer();
    }
  }
  return repondre_({ ok: true, message: "Serveur des colles en ligne." });
}

/* À lancer UNE fois après avoir collé ce code (bouton « Exécuter »). */
function installer() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss.getSheetByName(ONGLETS.classes)) throw new Error("Déjà installé : supprimez les onglets pour recommencer.");
  var code = function (n) {
    var c = "ABCDEFGHJKMNPQRSTUVWXYZ23456789", s = "";
    for (var i = 0; i < n; i++) s += c.charAt(Math.floor(Math.random() * c.length));
    return s;
  };
  var codes = { admin: code(10), acces: code(6) };
  COLLES.depart().matieres.forEach(function (m) { codes[m.id] = code(8); });
  viderCache_();
  var data = COLLES.depart(codes), st = store_(false);
  Object.keys(COLLES.TABLES).forEach(function (t) { st.save(t, data[t] || []); });
  st.terminer();
  var sh = ss.getSheetByName("Codes") || ss.insertSheet("Codes", 0);
  var lignes = [["Codes créés à l'installation (s'ils sont changés ensuite sur le site, cette liste n'est plus à jour)", ""],
    ["Code administrateur (à garder pour toi)", codes.admin],
    ["Code d'accès des élèves (le même pour toute la prépa)", codes.acces], ["", ""]];
  data.matieres.forEach(function (m) {
    var c = data.classes.filter(function (x) { return x.id === m.classe; })[0];
    lignes.push(["Code de gestion " + m.nom + ", " + c.nom, m.code]);
  });
  lignes.push(["", ""], ["Étape suivante : ajoute les listes d'élèves depuis le site (Espace gestion > Administration > Élèves).", ""],
    ["Vacances et jours fériés : onglet « Fermetures » (une ligne par période, dates au format AAAA-MM-JJ).", ""],
    ["Les codes se modifient depuis l'espace gestion, onglet Administration.", ""],
    ["Un même code peut ouvrir plusieurs matières : donnez-leur le même code.", ""]);
  sh.getRange(1, 1, lignes.length, 2).setValues(lignes);
  sh.autoResizeColumns(1, 2);
}
