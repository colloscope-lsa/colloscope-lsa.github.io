/* =====================================================================
   Serveur : stockage dans le Google Sheet qui contient ce script.
   ===================================================================== */

// Nom des onglets du Google Sheet
var ONGLETS = {
  classes: "Classes", eleves: "Élèves", matieres: "Matières", regles: "Règles",
  ponctuels: "Séances ponctuelles", annulations: "Annulations",
  inscriptions: "Inscriptions", journal: "Journal", reglages: "Réglages", ouvertures: "Ouvertures manuelles",
  fermetures: "Fermetures", archives: "Archives inscriptions"
};
var ECRITURE = { reserver: 1, annuler: 1, verifier: 1, gestion: 1 };

function store_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  // Lecture : un onglet absent = tableau vide (on ne crée rien pendant une simple lecture).
  function trouver(nom) { return ss.getSheetByName(ONGLETS[nom]); }
  // Écriture : crée l'onglet si besoin ; si deux requêtes le créent en même temps, on récupère l'existant.
  function onglet(nom, cols) {
    var sh = trouver(nom);
    if (!sh) {
      try { sh = ss.insertSheet(ONGLETS[nom]); } catch (e) { sh = trouver(nom); if (!sh) throw e; }
      sh.setFrozenRows(1);
    }
    // L'en-tête est réécrit à chaque écriture : il reste aligné avec les colonnes si le code évolue.
    sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight("bold");
    return sh;
  }
  function lire(sh, premiere, nb) {
    var head = sh.getRange(1, 1, 1, sh.getLastColumn()).getDisplayValues()[0];
    return sh.getRange(premiere, 1, nb, head.length).getDisplayValues()
      .filter(function (r) { return r.join("") !== ""; })
      .map(function (r) { var o = {}; head.forEach(function (k, i) { o[k] = r[i]; }); return o; });
  }
  return {
    load: function (nom) {
      var sh = trouver(nom);
      if (!sh || sh.getLastRow() < 2) return [];
      return lire(sh, 2, sh.getLastRow() - 1);
    },
    // Les n dernières lignes seulement
    loadTail: function (nom, n) {
      var sh = trouver(nom);
      if (!sh || sh.getLastRow() < 2) return [];
      var der = sh.getLastRow(), premiere = Math.max(2, der - n + 1);
      return lire(sh, premiere, der - premiere + 1);
    },
    // Écrit d'abord les nouvelles lignes, puis efface seulement ce qui dépasse :
    // une lecture simultanée ne voit jamais l'onglet vide.
    save: function (nom, rows) {
      var cols = COLLES.TABLES[nom], sh = onglet(nom, cols);
      var avant = Math.max(0, sh.getLastRow() - 1);
      if (rows.length) sh.getRange(2, 1, rows.length, cols.length).setNumberFormat("@").setValues(lignes_(cols, rows));
      if (avant > rows.length) sh.getRange(2 + rows.length, 1, avant - rows.length, Math.max(cols.length, sh.getLastColumn())).clearContent();
    },
    append: function (nom, rows) {
      if (!rows.length) return;
      var cols = COLLES.TABLES[nom], sh = onglet(nom, cols);
      sh.getRange(sh.getLastRow() + 1, 1, rows.length, cols.length).setNumberFormat("@").setValues(lignes_(cols, rows));
    }
  };
}

function lignes_(cols, rows) {
  return rows.map(function (o) { return cols.map(function (k) { return o[k] === undefined ? "" : String(o[k]); }); });
}

function maintenant_() {
  var d = new Date(), tz = "Europe/Paris";
  return {
    date: Utilities.formatDate(d, tz, "yyyy-MM-dd"),
    time: Utilities.formatDate(d, tz, "HH:mm"),
    iso: Utilities.formatDate(d, tz, "yyyy-MM-dd'T'HH:mm:ss")
  };
}

function repondre_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var p;
  try { p = JSON.parse(e.postData.contents); } catch (err) { p = null; }
  if (!p || typeof p !== "object") return repondre_({ ok: false, error: "Requête illisible." });
  var lock = null;
  if (ECRITURE[p.action]) {
    // Les écritures passent une par une : deux élèves ne peuvent pas prendre la même dernière place.
    lock = LockService.getScriptLock();
    if (!lock.tryLock(25000)) return repondre_({ ok: false, error: "Beaucoup de monde en même temps : réessaie dans quelques secondes." });
  }
  try {
    return repondre_(COLLES.traiter(store_(), p, maintenant_()));
  } catch (err) {
    console.error(err);
    return repondre_({ ok: false, error: "Erreur du serveur. Réessaie plus tard." });
  } finally {
    if (lock) lock.releaseLock();
  }
}

// Adresse ouverte par le bouton « Calendrier Apple » : renvoie le fichier agenda de la colle.
function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action === "ics") {
    try {
      var r = COLLES.traiter(store_(), { action: "ics", c: p.c, app: p.app }, maintenant_());
      if (r.ok) return ContentService.createTextOutput(r.ics).setMimeType(ContentService.MimeType.ICAL);
      return ContentService.createTextOutput(r.error);
    } catch (err) {
      console.error(err);
      return ContentService.createTextOutput("Erreur du serveur. Réessaie plus tard.");
    }
  }
  return repondre_({ ok: true, message: "Serveur des colles en ligne." });
}

/* À lancer UNE fois après avoir collé ce code (bouton « Exécuter »). */
function installer() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss.getSheetByName(ONGLETS.classes)) throw new Error("Déjà installé : supprimez les onglets pour recommencer.");
  var code = function (n) {
    var c = "ABCDEFGHJKMNPQRSTUVWXYZ23456789", s = "";
    for (var i = 0; i < n; i++) s += c.charAt(Math.floor(Math.random() * c.length));
    return s;
  };
  var codes = { admin: code(10), acces: code(6) };
  COLLES.depart().matieres.forEach(function (m) { codes[m.id] = code(8); });
  var data = COLLES.depart(codes), st = store_();
  Object.keys(COLLES.TABLES).forEach(function (t) { st.save(t, data[t] || []); });
  var sh = ss.getSheetByName("Codes") || ss.insertSheet("Codes", 0);
  var lignes = [["Codes créés à l'installation (s'ils sont changés ensuite sur le site, cette liste n'est plus à jour)", ""],
    ["Code administrateur (à garder pour toi)", codes.admin],
    ["Code d'accès des élèves (le même pour toute la prépa)", codes.acces], ["", ""]];
  data.matieres.forEach(function (m) {
    var c = data.classes.filter(function (x) { return x.id === m.classe; })[0];
    lignes.push(["Code de gestion " + m.nom + ", " + c.nom, m.code]);
  });
  lignes.push(["", ""], ["Étape suivante : ajoute les listes d'élèves depuis le site (Espace gestion > Administration > Élèves).", ""],
    ["Vacances et jours fériés : onglet « Fermetures » (une ligne par période, dates au format AAAA-MM-JJ).", ""],
    ["Les codes se modifient depuis l'espace gestion, onglet Administration.", ""],
    ["Un même code peut ouvrir plusieurs matières : donnez-leur le même code.", ""]);
  sh.getRange(1, 1, lignes.length, 2).setValues(lignes);
  sh.autoResizeColumns(1, 2);
}
