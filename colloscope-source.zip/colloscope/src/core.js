/* =====================================================================
   Colles — cœur partagé
   Ce même code tourne dans le site (mode démonstration) et sur le serveur
   (Google Apps Script). Il calcule les créneaux et applique les règles.
   ===================================================================== */
var COLLES = (function () {
  "use strict";

  /* ---------- Calendrier scolaire (zone A, académie de Clermont-Ferrand) ---------- */
  // Dates incluses. Aucune séance générée par une règle ces jours-là.
  var FERME = [
    ["2026-10-17", "2026-11-01", "Vacances de la Toussaint"],
    ["2026-11-11", "2026-11-11", "Armistice"],
    ["2026-12-19", "2027-01-03", "Vacances de Noël"],
    ["2027-02-13", "2027-02-28", "Vacances d'hiver"],
    ["2027-03-29", "2027-03-29", "Lundi de Pâques"],
    ["2027-04-10", "2027-04-25", "Vacances de printemps"],
    ["2027-05-06", "2027-05-07", "Pont de l'Ascension"],
    ["2027-05-17", "2027-05-17", "Lundi de Pentecôte"]
  ];

  /* ---------- Structure des tableaux (= onglets du Google Sheet) ---------- */
  var TABLES = {
    classes:      ["id", "nom", "code"],
    eleves:       ["classe", "nom", "pin", "echecs"],
    matieres:     ["id", "classe", "nom", "couleur", "duree", "places", "info", "code"],
    regles:       ["id", "matiere", "jour", "heures", "frequence", "debut", "fin", "salle", "colleur"],
    ponctuels:    ["id", "matiere", "date", "heures", "salle", "colleur"],
    annulations:  ["source", "date", "motif"],
    inscriptions: ["creneau", "matiere", "date", "heure", "classe", "eleve", "le"],
    journal:      ["le", "action", "classe", "matiere", "date", "heure", "eleve", "par"],
    reglages:     ["cle", "valeur"],
    ouvertures:   ["matiere", "lundi", "le", "par"],   // colles ouvertes à la main avant la date prévue
    fermetures:   ["debut", "fin", "motif"],           // vacances et jours fériés (modifiables dans le Sheet)
    archives:     ["creneau", "matiere", "date", "heure", "classe", "eleve", "le"], // inscriptions de plus de 3 semaines
    avis:         ["le", "classe", "eleve", "matiere", "date", "heure"]   // colles annulées par la gestion, signalées à l'élève
  };

  var MAX_ECHECS = 10;
  var DAY = 864e5;

  /* ---------- Dates (chaînes AAAA-MM-JJ, sans fuseau) ---------- */
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function parseD(s) { var p = String(s).split("-"); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function fmtD(t) { var d = new Date(t); return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()); }
  function addDays(s, n) { return fmtD(parseD(s) + n * DAY); }
  function jourSemaine(s) { var w = new Date(parseD(s)).getUTCDay(); return w === 0 ? 7 : w; } // 1 = lundi … 7 = dimanche
  function lundi(s) { return addDays(s, 1 - jourSemaine(s)); }
  function semainesEntre(a, b) { return Math.round((parseD(lundi(b)) - parseD(lundi(a))) / (7 * DAY)); }
  function isDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s)) && fmtD(parseD(s)) === String(s); }
  function fermeDans(liste, date) {
    for (var i = 0; i < liste.length; i++) if (date >= liste[i][0] && date <= liste[i][1]) return liste[i][2] || "Fermé";
    return "";
  }
  function ferme(date) { return fermeDans(FERME, date); }
  function toMin(t) { var p = String(t).split(":"); return +p[0] * 60 + +p[1]; }
  function fromMin(m) { return pad(Math.floor(m / 60)) + ":" + pad(m % 60); }

  // « 8h », « 8h20 », « 08:20 », « 12 » → « 08:20 »
  function normHeure(t) {
    var m = String(t).trim().toLowerCase().match(/^(\d{1,2})\s*(?:[h:.]\s*(\d{2})?(?::\d{2})?)?$/);
    if (!m) return null;
    var h = +m[1], mi = m[2] ? +m[2] : 0;
    if (h > 23 || mi > 59) return null;
    return pad(h) + ":" + pad(mi);
  }
  // « 12h, 12h20 ; 16h » → ["12:00", "12:20", "16:00"]
  function parseHeures(str) {
    var out = [], bad = [];
    String(str || "").split(/[,;\s]+/).forEach(function (x) {
      if (!x) return;
      var n = normHeure(x);
      if (n) { if (out.indexOf(n) < 0) out.push(n); } else bad.push(x);
    });
    out.sort();
    return { heures: out, invalides: bad };
  }

  /* ---------- Petits outils ---------- */
  function hash(s) { // FNV-1a 32 bits, suffisant pour ne pas stocker les codes en clair
    var h = 0x811c9dc5;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return ("0000000" + h.toString(16)).slice(-8);
  }
  function pinHash(classe, eleve, pin) { return hash("colles|" + classe + "|" + eleve + "|" + pin); }
  function uid(prefix) { return prefix + Math.random().toString(36).slice(2, 8); }
  function str(v) { return v === undefined || v === null ? "" : String(v).trim(); }
  function err(msg) { var e = new Error(msg); e.utilisateur = true; return e; }
  function find(arr, fn) { for (var i = 0; i < arr.length; i++) if (fn(arr[i])) return arr[i]; return null; }

  /* ---------- Accès aux données (cache + écriture groupée) ---------- */
  // Une date tapée à la main dans le Sheet (« 05/10/2026 ») est ramenée au format AAAA-MM-JJ.
  var CHAMPS_DATE = { date: 1, debut: 1, fin: 1, lundi: 1 };
  function normDate(v) {
    var m = String(v).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    return m ? m[3] + "-" + pad(+m[2]) + "-" + pad(+m[1]) : v;
  }
  function ligneDe(name, r) {
    var o = {};
    TABLES[name].forEach(function (k) { o[k] = CHAMPS_DATE[k] ? normDate(str(r[k])) : str(r[k]); });
    return o;
  }
  function Db(store) {
    var cache = {}, dirty = {}, ajouts = {};
    return {
      t: function (name) {
        if (!cache[name]) {
          cache[name] = (store.load(name) || []).map(function (r) { return ligneDe(name, r); });
          if (ajouts[name]) cache[name] = cache[name].concat(ajouts[name]);
        }
        return cache[name];
      },
      // Les n dernières lignes seulement (journal : évite de tout relire à chaque visite)
      fin: function (name, n) {
        if (cache[name]) return cache[name].slice(-n);
        var rows = store.loadTail ? store.loadTail(name, n) : (store.load(name) || []).slice(-n);
        return rows.map(function (r) { return ligneDe(name, r); }).concat(ajouts[name] || []).slice(-n);
      },
      set: function (name, rows) { cache[name] = rows; dirty[name] = true; },
      touch: function (name) { dirty[name] = true; },
      // Ajout en fin de tableau, sans relire ni réécrire le reste (journal, archives)
      ajouter: function (name, row) { if (cache[name]) cache[name].push(row); (ajouts[name] = ajouts[name] || []).push(row); },
      reglage: function (cle, defaut) {
        var r = find(this.t("reglages"), function (x) { return x.cle === cle; });
        return r && r.valeur !== "" ? normDate(r.valeur) : defaut;
      },
      fermetures: function () {
        if (!this._f) this._f = this.t("fermetures").filter(function (x) { return isDate(x.debut); })
          .map(function (x) { return [x.debut, isDate(x.fin) ? x.fin : x.debut, x.motif]; });
        return this._f;
      },
      commit: function () {
        var self = this;
        Object.keys(dirty).forEach(function (n) { store.save(n, cache[n]); delete ajouts[n]; });
        Object.keys(ajouts).forEach(function (n) {
          if (store.append) store.append(n, ajouts[n]);
          else { var tout = self.t(n); store.save(n, tout); }   // sans ajout direct : on réécrit le tableau complet
        });
        dirty = {}; ajouts = {}; this._f = null;
      }
    };
  }

  /* ---------- Génération des séances et créneaux ---------- */
  function matiereDeSource(db, source) {
    var r = find(db.t("regles"), function (x) { return x.id === source; })
         || find(db.t("ponctuels"), function (x) { return x.id === source; });
    return r ? r.matiere : "";
  }

  // Séances d'une matière entre deux dates (incluses), triées.
  function seances(db, matiereId, de, a) {
    var out = [];
    var annul = db.t("annulations");
    function motifAnnul(source, date) {
      var x = find(annul, function (y) { return y.source === source && y.date === date; });
      return x ? (x.motif || "Séance annulée") : "";
    }
    db.t("regles").forEach(function (r) {
      if (r.matiere !== matiereId || !isDate(r.debut)) return;
      var jour = +r.jour, freq = Math.max(1, +r.frequence || 1);
      var debut = r.debut > de ? r.debut : de;
      for (var w = lundi(debut); w <= a; w = addDays(w, 7)) {
        if (r.fin && w > r.fin) break;
        if (semainesEntre(r.debut, w) % freq !== 0) continue;
        var date = addDays(w, jour - 1);
        if (date < de || date > a || date < lundi(r.debut) || (r.fin && date > r.fin)) continue;
        if (fermeDans(db.fermetures(), date)) continue;
        out.push({ source: r.id, type: "regle", date: date, heures: parseHeures(r.heures).heures,
                   salle: r.salle, colleur: r.colleur, annule: motifAnnul(r.id, date) });
      }
    });
    db.t("ponctuels").forEach(function (p) {
      if (p.matiere !== matiereId || p.date < de || p.date > a) return;
      out.push({ source: p.id, type: "ponctuel", date: p.date, heures: parseHeures(p.heures).heures,
                 salle: p.salle, colleur: p.colleur, annule: motifAnnul(p.id, p.date) });
    });
    out.sort(function (x, y) {
      if (x.date !== y.date) return x.date < y.date ? -1 : 1;
      var hx = x.heures[0] || "", hy = y.heures[0] || "";
      return hx < hy ? -1 : hx > hy ? 1 : 0;
    });
    return out;
  }

  function idCreneau(source, date, heure) { return source + "~" + date + "~" + heure; }
  function lireCreneau(id) {
    var p = String(id).split("~");
    return p.length === 3 ? { source: p[0], date: p[1], heure: p[2] } : null;
  }
  function estPasse(date, heure, now) { return date < now.date || (date === now.date && heure <= now.time); }

  // Les inscriptions d'une semaine de colle ouvrent N jours avant son lundi, à heure fixe.
  function ouverture(db, lun) {
    return { date: addDays(lun, -(+db.reglage("ouverture_jours", "14") || 0)), heure: normHeure(db.reglage("ouverture_heure", "12:00")) || "12:00" };
  }
  function ouverteALaMain(db, matiereId, lun) {
    return !!find(db.t("ouvertures"), function (x) { return x.matiere === matiereId && x.lundi === lun; });
  }
  function estOuvert(db, matiereId, lun, now) {
    if (ouverteALaMain(db, matiereId, lun)) return true;
    var o = ouverture(db, lun);
    return now.date > o.date || (now.date === o.date && now.time >= o.heure);
  }
  var SEMAINES_AFFICHEES = 12;
  function placesDe(m) { return Math.max(1, +m.places || 2); }

  // Séances d'une matière regroupées par semaine et numérotées (Colle 1, 2, 3…) depuis la rentrée.
  function semainesDe(db, matiereId, de, a) {
    var tout = seances(db, matiereId, db.reglage("debut_annee", "2026-09-01"), a);
    var out = [], parLundi = {};
    tout.forEach(function (s) {
      var l = lundi(s.date);
      if (!parLundi[l]) { parLundi[l] = { num: out.length + 1, lundi: l, seances: [] }; out.push(parLundi[l]); }
      parLundi[l].seances.push(s);
    });
    return out.filter(function (w) { return w.lundi >= lundi(de); });
  }
  function inscritsParCreneau(db) {
    var m = {};
    db.t("inscriptions").forEach(function (i) { (m[i.creneau] = m[i.creneau] || []).push(i); });
    return m;
  }

  // Vérifie qu'un créneau existe encore (règle, date, heure, non annulé).
  function creneauValide(db, id) {
    var c = lireCreneau(id);
    if (!c) return null;
    var m = matiereDeSource(db, c.source);
    if (!m) return null;
    var s = find(seances(db, m, c.date, c.date), function (x) { return x.source === c.source; });
    if (!s || s.annule || s.heures.indexOf(c.heure) < 0) return null;
    return { matiere: m, date: c.date, heure: c.heure, seance: s };
  }

  /* ---------- Contrôles d'accès ---------- */
  // Un seul code d'accès pour toute la prépa (réglage « code_acces »)
  function verifierAcces(db, p) {
    var code = db.reglage("code_acces", "");
    if (code && str(p.code).toUpperCase() !== code.toUpperCase()) throw err("Code d'accès incorrect.");
  }
  function classeAuth(db, p) {
    var c = find(db.t("classes"), function (x) { return x.id === str(p.classe); });
    if (!c) throw err("Classe introuvable.");
    verifierAcces(db, p);
    return c;
  }
  function eleveDe(db, classe, nom) {
    var e = find(db.t("eleves"), function (x) { return x.classe === classe && x.nom === str(nom); });
    if (!e) throw err("Élève introuvable dans cette classe.");
    return e;
  }
  function verifierPin(db, classe, e, pin) {
    pin = str(pin);
    if (!e.pin) {
      if (!/^\d{4}$/.test(pin)) throw err("Choisis un code personnel de 4 chiffres.");
      e.pin = pinHash(classe, e.nom, pin); e.echecs = "0"; db.touch("eleves");
      return true;
    }
    if (+e.echecs >= MAX_ECHECS) throw err("Code bloqué après trop d'essais. Demande au délégué de le réinitialiser.");
    if (pinHash(classe, e.nom, pin) !== e.pin) {
      e.echecs = String((+e.echecs || 0) + 1); db.touch("eleves"); db.commit();
      throw err("Code personnel incorrect.");
    }
    if (e.echecs !== "0") { e.echecs = "0"; db.touch("eleves"); }
    return true;
  }
  function gestionAuth(db, p) {
    var code = str(p.gcode).toUpperCase();
    if (!code) throw err("Code de gestion requis.");
    var admin = code === String(db.reglage("code_admin", "")).toUpperCase();
    var ids = db.t("matieres").filter(function (m) { return admin || (m.code && m.code.toUpperCase() === code); }).map(function (m) { return m.id; });
    if (!admin && !ids.length) throw err("Code incorrect.");
    return { admin: admin, matieres: ids };
  }
  function exigerMatiere(scope, id) {
    if (scope.matieres.indexOf(id) < 0) throw err("Cette matière n'est pas accessible avec ce code.");
  }
  function exigerAdmin(scope) { if (!scope.admin) throw err("Réservé au code administrateur."); }

  function journal(db, now, action, o, par) {
    db.ajouter("journal", { le: now.iso, action: action, classe: o.classe || "", matiere: o.matiere || "",
      date: o.date || "", heure: o.heure || "", eleve: o.eleve || "", par: par || "" });
    // L'élève concerné le verra en arrivant sur le site (petit tableau à part : le journal n'est jamais relu côté élève)
    if (action === "Annulée par la gestion" && o.eleve)
      db.ajouter("avis", { le: now.iso, classe: o.classe || "", eleve: o.eleve, matiere: o.matiere || "", date: o.date || "", heure: o.heure || "" });
  }

  // Après une modification du planning : retire les inscriptions futures devenues invalides.
  function purger(db, now, par) {
    var garde = [], retire = 0;
    db.t("inscriptions").forEach(function (i) {
      if (estPasse(i.date, i.heure, now) || creneauValide(db, i.creneau)) { garde.push(i); return; }
      retire++;
      journal(db, now, "Annulée par la gestion", i, par);
    });
    if (retire) db.set("inscriptions", garde);
    return retire;
  }

  /* ---------- Vue élève ---------- */
  function etat(db, p, now) {
    var c = classeAuth(db, p);
    var nom = str(p.eleve);
    var eleves = db.t("eleves").filter(function (e) { return e.classe === c.id; })
      .map(function (e) { return e.nom; }).sort(function (a, b) { return a.localeCompare(b, "fr"); });
    var moi = nom ? find(db.t("eleves"), function (e) { return e.classe === c.id && e.nom === nom; }) : null;
    var fin = addDays(now.date, 7 * SEMAINES_AFFICHEES);
    var parCreneau = inscritsParCreneau(db);
    var matieres = db.t("matieres").filter(function (m) { return m.classe === c.id; }).map(function (m) {
      var duree = +m.duree || 40, places = placesDe(m);
      var semaines = semainesDe(db, m.id, db.reglage("debut_annee", "2026-09-01"), fin).map(function (w) {
        var ouvert = estOuvert(db, m.id, w.lundi, now), mien = null, libres = 0, toutFini = true;
        var ss = w.seances.map(function (s) {
          return {
            source: s.source, date: s.date, salle: s.salle, colleur: s.colleur, annule: s.annule,
            creneaux: s.heures.map(function (h) {
              var id = idCreneau(s.source, s.date, h), qui = parCreneau[id] || [];
              var estMoi = moi && qui.some(function (i) { return i.eleve === moi.nom && i.classe === c.id; });
              var passe = estPasse(s.date, h, now), reste = Math.max(0, places - qui.length);
              var etat = s.annule ? "annule" : estMoi ? "moi" : passe ? "passe" : reste ? "libre" : "complet";
              if (estMoi) mien = { creneau: id, date: s.date, debut: h };
              if (!s.annule && !passe) { toutFini = false; libres += reste; }
              return { id: id, debut: h, fin: fromMin(toMin(h) + duree), places: places, restantes: reste, etat: etat,
                       noms: qui.map(function (i) { return i.eleve; }) };
            })
          };
        });
        return {
          num: w.num, lundi: w.lundi, seances: ss, ouvert: ouvert, ouverture: ouverture(db, w.lundi),
          termine: toutFini, annulee: ss.every(function (s) { return s.annule; }), libres: ouvert ? libres : 0, moi: mien
        };
      });
      return { id: m.id, nom: m.nom, couleur: m.couleur, info: m.info, duree: duree, places: places, semaines: semaines };
    });
    var mes = [], alertes = [];
    if (moi) {
      db.t("inscriptions").forEach(function (i) {
        if (i.classe !== c.id || i.eleve !== moi.nom || i.date < now.date) return;
        var v = creneauValide(db, i.creneau);
        var m = find(db.t("matieres"), function (x) { return x.id === i.matiere; });
        if (!v || !m) return;
        var w = find(semainesDe(db, m.id, i.date, i.date), function () { return true; });
        mes.push({ creneau: i.creneau, matiere: m.id, matiereNom: m.nom, couleur: m.couleur, num: w ? w.num : "", date: i.date,
          debut: i.heure, fin: fromMin(toMin(i.heure) + (+m.duree || 40)), salle: v.seance.salle,
          colleur: v.seance.colleur, info: m.info, passe: estPasse(i.date, i.heure, now) });
      });
      mes.sort(function (a, b) { return (a.date + a.debut) < (b.date + b.debut) ? -1 : 1; });
      db.t("avis").forEach(function (j) {
        if (j.classe === c.id && j.eleve === moi.nom && j.date >= now.date) {
          var m = find(db.t("matieres"), function (x) { return x.id === j.matiere; });
          alertes.push({ matiereNom: m ? m.nom : "Colle", date: j.date, heure: j.heure, le: j.le });
        }
      });
    }
    return {
      ok: true, aujourdhui: now.date, maintenant: now.time,
      classe: { id: c.id, nom: c.nom }, eleves: eleves,
      moi: moi ? { nom: moi.nom, aCode: !!moi.pin } : null,
      matieres: matieres, mesColles: mes, alertes: alertes,
      autres: db.t("classes").filter(function (x) { return x.id !== c.id; }).map(function (x) { return { id: x.id, nom: x.nom }; })
    };
  }

  /* ---------- Recherche d'un camarade, toutes classes (lecture seule) ---------- */
  function annuaire(db, p, now) {
    classeAuth(db, p);
    var mats = {};
    db.t("matieres").forEach(function (m) { mats[m.id] = m; });
    var colles = [];
    db.t("inscriptions").forEach(function (i) {
      if (estPasse(i.date, i.heure, now)) return;
      var m = mats[i.matiere], v = m && creneauValide(db, i.creneau);
      if (!v) return;
      colles.push({ nom: i.eleve, classe: i.classe, matiere: m.nom, couleur: m.couleur, date: i.date, debut: i.heure,
        fin: fromMin(toMin(i.heure) + (+m.duree || 40)), salle: v.seance.salle, colleur: v.seance.colleur });
    });
    colles.sort(function (a, b) { return (a.date + a.debut) < (b.date + b.debut) ? -1 : 1; });
    return {
      ok: true,
      classes: db.t("classes").map(function (c) { return { id: c.id, nom: c.nom }; }),
      eleves: db.t("eleves").map(function (e) { return { nom: e.nom, classe: e.classe }; }),
      colles: colles
    };
  }

  /* ---------- Fichier agenda (.ics) : sans rappel imposé, chacun garde les réglages de son agenda ---------- */
  var LYCEE = "Lycée Sidoine Apollinaire";
  function icsTexte(c) {
    var dt = function (d, t) { return d.replace(/-/g, "") + "T" + t.replace(":", "") + "00"; };
    var x = function (t) { return String(t).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n"); };
    var titre = "Colle de " + c.matiereNom + (c.num ? " (colle " + c.num + ")" : "");
    var lieu = c.salle ? "Salle " + c.salle + ", " + LYCEE : LYCEE;
    var details = [c.info, c.colleur ? "Colleur : " + c.colleur : "", c.url ? "En cas de changement, le Colloscope fait foi : " + c.url : ""].filter(Boolean).join("\n");
    var stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
    return [
      "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Colloscope//FR", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
      "BEGIN:VTIMEZONE", "TZID:Europe/Paris",
      "BEGIN:DAYLIGHT", "TZOFFSETFROM:+0100", "TZOFFSETTO:+0200", "TZNAME:CEST", "DTSTART:19700329T020000", "RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU", "END:DAYLIGHT",
      "BEGIN:STANDARD", "TZOFFSETFROM:+0200", "TZOFFSETTO:+0100", "TZNAME:CET", "DTSTART:19701025T030000", "RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU", "END:STANDARD",
      "END:VTIMEZONE",
      "BEGIN:VEVENT",
      "UID:" + String(c.creneau).replace(/[^A-Za-z0-9-]/g, "-") + "@colloscope",
      "DTSTAMP:" + stamp,
      "DTSTART;TZID=Europe/Paris:" + dt(c.date, c.debut),
      "DTEND;TZID=Europe/Paris:" + dt(c.date, c.fin),
      "SUMMARY:" + x(titre), "LOCATION:" + x(lieu), "DESCRIPTION:" + x(details),
      "END:VEVENT", "END:VCALENDAR"
    ].map(plier).join("\r\n");
  }
  // Une ligne iCalendar ne doit pas dépasser 75 octets : on la coupe, la suite commence par une espace.
  function plier(ligne) {
    var out = "", n = 0;
    for (var i = 0; i < ligne.length; i++) {
      var ch = ligne.charAt(i), c = ligne.charCodeAt(i), octets = c < 0x80 ? 1 : c < 0x800 ? 2 : (c >= 0xD800 && c <= 0xDBFF) ? 4 : 3;
      if (c >= 0xD800 && c <= 0xDBFF && i + 1 < ligne.length) { ch += ligne.charAt(++i); }
      if (n + octets > 75) { out += "\r\n "; n = 1; }
      out += ch; n += octets;
    }
    return out;
  }
  function icsCreneau(db, p) {
    var v = creneauValide(db, str(p.c));
    if (!v) throw err("Ce créneau n'existe plus.");
    var m = find(db.t("matieres"), function (x) { return x.id === v.matiere; });
    if (!m) throw err("Ce créneau n'existe plus.");
    var w = find(semainesDe(db, m.id, v.date, v.date), function () { return true; });
    return { ok: true, ics: icsTexte({ creneau: str(p.c), matiereNom: m.nom, num: w ? w.num : "", date: v.date, debut: v.heure,
      fin: fromMin(toMin(v.heure) + (+m.duree || 40)), salle: v.seance.salle, colleur: v.seance.colleur, info: m.info, url: str(p.app) }) };
  }

  /* ---------- Consultation d'une autre classe (lecture seule) ---------- */
  function consulter(db, p, now) {
    classeAuth(db, p);
    var cible = find(db.t("classes"), function (x) { return x.id === str(p.cible); });
    if (!cible) throw err("Classe introuvable.");
    var fin = addDays(now.date, 7 * SEMAINES_AFFICHEES), parCreneau = inscritsParCreneau(db);
    var matieres = db.t("matieres").filter(function (m) { return m.classe === cible.id; }).map(function (m) {
      var duree = +m.duree || 40;
      return {
        id: m.id, nom: m.nom, couleur: m.couleur, info: m.info, duree: duree, places: placesDe(m),
        semaines: semainesDe(db, m.id, now.date, fin).map(function (w) {
          var fini = true;
          var ss = w.seances.map(function (s) {
            return { date: s.date, salle: s.salle, colleur: s.colleur, annule: s.annule,
              creneaux: s.heures.map(function (h) {
                var passe = estPasse(s.date, h, now);
                if (!passe && !s.annule) fini = false;
                return { debut: h, fin: fromMin(toMin(h) + duree), passe: passe,
                  noms: (parCreneau[idCreneau(s.source, s.date, h)] || []).map(function (i) { return i.eleve; }) };
              }) };
          });
          return { num: w.num, lundi: w.lundi, ouvert: estOuvert(db, m.id, w.lundi, now), ouverture: ouverture(db, w.lundi),
            termine: fini, annulee: ss.every(function (s) { return s.annule; }), seances: ss };
        })
      };
    });
    return { ok: true, aujourdhui: now.date, classe: { id: cible.id, nom: cible.nom }, matieres: matieres };
  }

  function reserver(db, p, now) {
    var c = classeAuth(db, p), e = eleveDe(db, c.id, p.eleve);
    verifierPin(db, c.id, e, p.pin);
    var idc = str(p.creneau), v = creneauValide(db, idc);
    if (!v) throw err("Ce créneau n'existe plus. Actualise la page.");
    var m = find(db.t("matieres"), function (x) { return x.id === v.matiere; });
    if (!m || m.classe !== c.id) throw err("Ce créneau ne concerne pas ta classe.");
    if (estPasse(v.date, v.heure, now)) throw err("Ce créneau est déjà passé.");
    if (!estOuvert(db, v.matiere, lundi(v.date), now)) {
      var o = ouverture(db, lundi(v.date));
      throw err("Les inscriptions pour cette colle ouvrent le " + o.date.split("-").reverse().join("/") + " à " + o.heure.replace(":", "h") + ".");
    }
    var ins = db.t("inscriptions");
    var deja = ins.filter(function (i) { return i.creneau === idc; });
    if (deja.some(function (i) { return i.eleve === e.nom && i.classe === c.id; })) return { ok: true };
    if (deja.length >= placesDe(m)) throw err("Trop tard : ce créneau vient d'être complété.");
    // Une colle par matière et par semaine : l'ancienne est remplacée.
    var sem = lundi(v.date), ancienne = null;
    var garde = ins.filter(function (i) {
      var meme = i.classe === c.id && i.eleve === e.nom && i.matiere === m.id && lundi(i.date) === sem;
      if (meme && !estPasse(i.date, i.heure, now)) { ancienne = i; return false; }
      return true;
    });
    if (find(garde, function (i) { return i.classe === c.id && i.eleve === e.nom && i.matiere === m.id && lundi(i.date) === sem; }))
      throw err("Tu as déjà passé ta colle de " + m.nom + " cette semaine.");
    garde.push({ creneau: idc, matiere: m.id, date: v.date, heure: v.heure, classe: c.id, eleve: e.nom, le: now.iso });
    db.set("inscriptions", garde);
    journal(db, now, ancienne ? "Modification" : "Inscription",
      { classe: c.id, matiere: m.id, date: v.date, heure: v.heure, eleve: e.nom }, ancienne ? "avant : " + ancienne.date + " " + ancienne.heure : "");
    return { ok: true, remplace: ancienne ? { date: ancienne.date, heure: ancienne.heure } : null };
  }

  function annuler(db, p, now) {
    var c = classeAuth(db, p), e = eleveDe(db, c.id, p.eleve);
    verifierPin(db, c.id, e, p.pin);
    var ins = db.t("inscriptions");
    var idc = str(p.creneau);
    var i = find(ins, function (x) { return x.creneau === idc && x.eleve === e.nom && x.classe === c.id; });
    if (!i) throw err("Inscription introuvable.");
    if (estPasse(i.date, i.heure, now)) throw err("Cette colle est déjà passée.");
    db.set("inscriptions", ins.filter(function (x) { return x !== i; }));
    journal(db, now, "Désinscription", i, "");
    return { ok: true };
  }

  function verifierCode(db, p) {
    var c = classeAuth(db, p), e = eleveDe(db, c.id, p.eleve);
    verifierPin(db, c.id, e, p.pin);
    return { ok: true };
  }

  /* ---------- Gestion (professeurs, délégués) ---------- */
  function vueGestion(db, p, now) {
    var scope = gestionAuth(db, p);
    var dans = function (x) { return scope.matieres.indexOf(x.matiere) >= 0; };
    var parCreneau = inscritsParCreneau(db);
    var fin = addDays(now.date, 7 * SEMAINES_AFFICHEES);
    var classes = db.t("classes").map(function (c) {
      return scope.admin ? { id: c.id, nom: c.nom, code: c.code } : { id: c.id, nom: c.nom };
    });
    var matieres = db.t("matieres").filter(function (m) { return scope.matieres.indexOf(m.id) >= 0; }).map(function (m) {
      var duree = +m.duree || 40;
      var tous = db.t("eleves").filter(function (e) { return e.classe === m.classe; }).map(function (e) { return e.nom; });
      return {
        id: m.id, classe: m.classe, nom: m.nom, couleur: m.couleur, duree: duree, places: placesDe(m), info: m.info,
        code: scope.admin ? m.code : undefined,
        semaines: semainesDe(db, m.id, addDays(now.date, -7), fin).map(function (w) {
          var inscrits = {};
          var ss = w.seances.map(function (s) {
            return { source: s.source, type: s.type, date: s.date, salle: s.salle, colleur: s.colleur, annule: s.annule,
              creneaux: s.heures.map(function (h) {
                var id = idCreneau(s.source, s.date, h);
                var noms = (parCreneau[id] || []).map(function (i) { inscrits[i.eleve] = 1; return i.eleve; });
                return { id: id, debut: h, fin: fromMin(toMin(h) + duree), eleves: noms };
              }) };
          });
          return { num: w.num, lundi: w.lundi, ouverture: ouverture(db, w.lundi), ouvert: estOuvert(db, m.id, w.lundi, now),
            aLaMain: ouverteALaMain(db, m.id, w.lundi), termine: ss.every(function (s) { return s.annule || s.creneaux.every(function (c) { return estPasse(s.date, c.debut, now); }); }), seances: ss,
            manquants: ss.every(function (s) { return s.annule; }) ? [] : tous.filter(function (n) { return !inscrits[n]; }).sort(function (a, b) { return a.localeCompare(b, "fr"); }) };
        })
      };
    });
    var out = {
      ok: true, admin: scope.admin, aujourdhui: now.date, classes: classes, matieres: matieres,
      regles: db.t("regles").filter(dans), ponctuels: db.t("ponctuels").filter(dans),
      journal: db.fin("journal", 2000).filter(function (j) { return scope.admin || scope.matieres.indexOf(j.matiere) >= 0; }).slice(-200).reverse()
    };
    if (scope.admin) {
      out.eleves = db.t("eleves").map(function (e) {
        return { classe: e.classe, nom: e.nom, aCode: !!e.pin, bloque: +e.echecs >= MAX_ECHECS };
      });
      out.fermetures = db.fermetures().map(function (f) { return { debut: f[0], fin: f[1], motif: f[2] }; });
      out.reglages = { code_acces: db.reglage("code_acces", ""), ouverture_jours: db.reglage("ouverture_jours", "14"), ouverture_heure: db.reglage("ouverture_heure", "12:00"), debut_annee: db.reglage("debut_annee", "2026-09-01") };
    }
    return out;
  }

  function validerSource(o, avecJour) {
    var h = parseHeures(o.heures);
    if (h.invalides.length) throw err("Heure non reconnue : « " + h.invalides[0] + " ». Exemple : 12h, 12h20, 16h.");
    if (!h.heures.length) throw err("Indique au moins une heure de passage.");
    if (avecJour) {
      if (!(+o.jour >= 1 && +o.jour <= 6)) throw err("Choisis un jour de la semaine.");
      if (!isDate(o.debut)) throw err("Date de début invalide.");
      if (o.fin && !isDate(o.fin)) throw err("Date de fin invalide.");
      if (o.fin && o.fin < o.debut) throw err("La date de fin est avant la date de début.");
      if ([1, 2, 3, 4].indexOf(+o.frequence) < 0) throw err("Fréquence invalide.");
    } else if (!isDate(o.date)) throw err("Date invalide.");
    return h.heures.join(", ");
  }

  function upsert(db, table, row, cols) {
    var rows = db.t(table);
    var ex = row.id ? find(rows, function (x) { return x.id === row.id; }) : null;
    if (!ex) { ex = { id: uid(table.charAt(0)) }; cols.forEach(function (k) { if (k !== "id") ex[k] = ""; }); rows.push(ex); }
    cols.forEach(function (k) { if (k !== "id" && row[k] !== undefined) ex[k] = str(row[k]); });
    db.touch(table);
    return ex;
  }

  function gestion(db, p, now) {
    var scope = gestionAuth(db, p), par = scope.admin ? "admin" : "gestion";
    var a = str(p.op), o = p.data || {};
    var res = { ok: true };

    if (a === "regle") {
      var exR = o.id ? find(db.t("regles"), function (x) { return x.id === o.id; }) : null;
      if (exR) exigerMatiere(scope, exR.matiere);
      exigerMatiere(scope, str(o.matiere));
      o.heures = validerSource(o, true);
      res.id = upsert(db, "regles", o, TABLES.regles).id;
    } else if (a === "regle_suppr" || a === "ponctuel_suppr") {
      var table = a === "regle_suppr" ? "regles" : "ponctuels";
      var r = find(db.t(table), function (x) { return x.id === str(o.id); });
      if (!r) throw err("Élément introuvable.");
      exigerMatiere(scope, r.matiere);
      db.set(table, db.t(table).filter(function (x) { return x !== r; }));
      db.set("annulations", db.t("annulations").filter(function (x) { return x.source !== r.id; }));
    } else if (a === "ponctuel") {
      var exP = o.id ? find(db.t("ponctuels"), function (x) { return x.id === o.id; }) : null;
      if (exP) exigerMatiere(scope, exP.matiere);
      exigerMatiere(scope, str(o.matiere));
      o.heures = validerSource(o, false);
      res.id = upsert(db, "ponctuels", o, TABLES.ponctuels).id;
    } else if (a === "annulation") {
      var m = matiereDeSource(db, str(o.source));
      if (!m) throw err("Séance introuvable.");
      exigerMatiere(scope, m);
      var ann = db.t("annulations");
      if (!isDate(str(o.date))) throw err("Date invalide.");
      var ex = find(ann, function (x) { return x.source === str(o.source) && x.date === str(o.date); });
      if (o.annuler) {
        if (!ex) ann.push({ source: str(o.source), date: str(o.date), motif: str(o.motif) });
        else ex.motif = str(o.motif);
      } else if (ex) ann.splice(ann.indexOf(ex), 1);
      db.touch("annulations");
    } else if (a === "desinscrire") {
      var ins = db.t("inscriptions");
      var i = find(ins, function (x) { return x.creneau === str(o.creneau) && x.eleve === str(o.eleve); });
      if (!i) throw err("Inscription introuvable.");
      exigerMatiere(scope, i.matiere);
      db.set("inscriptions", ins.filter(function (x) { return x !== i; }));
      journal(db, now, "Annulée par la gestion", i, par);
    } else if (a === "matiere") {
      exigerAdmin(scope);
      // Modification partielle : les champs non fournis gardent leur valeur actuelle
      var exM = o.id ? find(db.t("matieres"), function (x) { return x.id === str(o.id); }) : null;
      if (exM) TABLES.matieres.forEach(function (k) { if (o[k] === undefined) o[k] = exM[k]; });
      if (!str(o.nom)) throw err("Nom de matière requis.");
      if (!find(db.t("classes"), function (c) { return c.id === str(o.classe); })) throw err("Classe inconnue.");
      var codeM = str(o.code).toUpperCase();
      if (codeM && codeM === String(db.reglage("code_admin", "")).toUpperCase()) throw err("Ce code est déjà le code administrateur.");
      if (codeM && codeM === String(db.reglage("code_acces", "")).toUpperCase()) throw err("Ce code est le code d'accès des élèves : choisis-en un autre, sinon tous les élèves pourraient gérer la matière.");
      if (o.couleur && !/^#[0-9a-fA-F]{6}$/.test(str(o.couleur))) throw err("Couleur invalide.");
      if (o.places !== undefined && !(+o.places >= 1 && +o.places <= 10)) throw err("Nombre d'élèves par créneau invalide (1 à 10).");
      if (o.duree !== undefined && !(+o.duree >= 5 && +o.duree <= 240)) throw err("Durée invalide (5 à 240 minutes).");
      res.id = upsert(db, "matieres", o, TABLES.matieres).id;
    } else if (a === "matiere_suppr") {
      exigerAdmin(scope);
      var mid = str(o.id);
      db.set("matieres", db.t("matieres").filter(function (x) { return x.id !== mid; }));
      var gone = {};
      ["regles", "ponctuels"].forEach(function (t) {
        db.set(t, db.t(t).filter(function (x) { if (x.matiere === mid) { gone[x.id] = 1; return false; } return true; }));
      });
      db.set("annulations", db.t("annulations").filter(function (x) { return !gone[x.source]; }));
    } else if (a === "classe") {
      exigerAdmin(scope);
      if (!str(o.nom)) throw err("Nom de classe requis.");
      res.id = upsert(db, "classes", o, TABLES.classes).id;
    } else if (a === "eleves") {
      exigerAdmin(scope);
      var cid = str(o.classe);
      if (!find(db.t("classes"), function (c) { return c.id === cid; })) throw err("Classe inconnue.");
      var noms = String(o.noms || "").split(/\n+/).map(function (n) { return n.replace(/\s*\(.*?\)\s*$/, "").replace(/^[*\-•\s]+/, "").replace(/\s+/g, " ").trim(); })
        .filter(function (n, k, arr) { return n && arr.indexOf(n) === k; });
      var anciens = db.t("eleves");
      var autres = anciens.filter(function (e) { return e.classe !== cid; });
      var liste = noms.map(function (n) {
        var ex = find(anciens, function (e) { return e.classe === cid && e.nom === n; });
        return ex || { classe: cid, nom: n, pin: "", echecs: "0" };
      });
      db.set("eleves", autres.concat(liste));
      res.nombre = liste.length;
      res.ajoutes = liste.filter(function (e) { return !find(anciens, function (x) { return x === e; }); }).length;
      res.retires = anciens.filter(function (e) { return e.classe === cid && liste.indexOf(e) < 0; }).length;
    } else if (a === "code_reset") {
      exigerAdmin(scope);
      var e = find(db.t("eleves"), function (x) { return x.classe === str(o.classe) && x.nom === str(o.nom); });
      if (!e) throw err("Élève introuvable.");
      e.pin = ""; e.echecs = "0"; db.touch("eleves");
      journal(db, now, "Code personnel réinitialisé", { classe: e.classe, eleve: e.nom }, par);
    } else if (a === "reglages") {
      exigerAdmin(scope);
      var jours = +o.ouverture_jours, heure = normHeure(o.ouverture_heure);
      if (!/^\d{1,3}$/.test(str(o.ouverture_jours)) || jours > 120) throw err("Nombre de jours invalide (0 à 120).");
      if (!heure) throw err("Heure d'ouverture invalide. Exemple : 12h");
      if (o.debut_annee && !isDate(o.debut_annee)) throw err("Date de rentrée invalide.");
      var rg = db.t("reglages");
      [["ouverture_jours", String(jours)], ["ouverture_heure", heure], ["debut_annee", str(o.debut_annee)]].forEach(function (kv) {
        if (!kv[1]) return;
        var x = find(rg, function (y) { return y.cle === kv[0]; });
        if (x) x.valeur = kv[1]; else rg.push({ cle: kv[0], valeur: kv[1] });
      });
      db.touch("reglages");
    } else if (a === "ouverture") {
      // Ouvrir une colle à la main (ou revenir à l'ouverture automatique)
      var mo = str(o.matiere), lo = str(o.lundi);
      exigerMatiere(scope, mo);
      if (!isDate(lo) || jourSemaine(lo) !== 1) throw err("Semaine invalide.");
      var ouv = db.t("ouvertures").filter(function (x) { return !(x.matiere === mo && x.lundi === lo); });
      if (o.ouvrir) ouv.push({ matiere: mo, lundi: lo, le: now.iso, par: par });
      db.set("ouvertures", ouv);
      var mm = find(db.t("matieres"), function (x) { return x.id === mo; });
      journal(db, now, o.ouvrir ? "Inscriptions ouvertes à la main" : "Ouverture automatique rétablie", { classe: mm ? mm.classe : "", matiere: mo, date: lo }, par);
    } else if (a === "code_acces") {
      exigerAdmin(scope);
      var nouveau = str(o.code);
      if (!/^[A-Za-z0-9]{4,20}$/.test(nouveau)) throw err("Le code doit faire de 4 à 20 lettres ou chiffres, sans espace.");
      var NOUV = nouveau.toUpperCase();
      if (NOUV === String(db.reglage("code_admin", "")).toUpperCase() || find(db.t("matieres"), function (m) { return m.code && m.code.toUpperCase() === NOUV; }))
        throw err("Ce code est déjà utilisé pour la gestion. Choisis-en un autre.");
      var rgA = db.t("reglages"), xA = find(rgA, function (y) { return y.cle === "code_acces"; });
      if (xA) xA.valeur = nouveau; else rgA.push({ cle: "code_acces", valeur: nouveau });
      db.touch("reglages");
    } else throw err("Action inconnue.");

    res.retirees = purger(db, now, par);
    return res;
  }

  function archiver(db, now) {
    var av = db.t("avis");   // alertes dont la colle est passée : plus utiles
    if (av.some(function (x) { return x.date < now.date; })) db.set("avis", av.filter(function (x) { return x.date >= now.date; }));
    var limite = addDays(now.date, -21), ins = db.t("inscriptions");
    var vieilles = ins.filter(function (i) { return i.date < limite; });
    if (vieilles.length < 40) return;
    vieilles.forEach(function (i) { db.ajouter("archives", i); });
    db.set("inscriptions", ins.filter(function (i) { return i.date >= limite; }));
  }

  /* ---------- Point d'entrée unique ---------- */
  function traiter(store, p, now) {
    var db = Db(store);
    p = p && typeof p === "object" ? p : {};
    try {
      var r;
      if (["reserver", "annuler", "gestion"].indexOf(str(p.action)) >= 0) archiver(db, now);
      switch (str(p.action)) {
        case "classes": verifierAcces(db, p); r = { ok: true, classes: db.t("classes").map(function (c) { return { id: c.id, nom: c.nom }; }) }; break;
        case "etat": r = etat(db, p, now); break;
        case "consulter": r = consulter(db, p, now); break;
        case "annuaire": r = annuaire(db, p, now); break;
        case "ics": r = icsCreneau(db, p); break;
        case "verifier": r = verifierCode(db, p); break;
        case "reserver": r = reserver(db, p, now); break;
        case "annuler": r = annuler(db, p, now); break;
        case "gestion_vue": r = vueGestion(db, p, now); break;
        case "gestion": r = gestion(db, p, now); break;
        default: throw err("Action inconnue.");
      }
      // Après une réservation ou une annulation, on renvoie directement le nouvel état : un aller-retour de moins.
      if (r && r.ok && (p.action === "reserver" || p.action === "annuler")) {
        try { var et = etat(db, p, now); if (et && et.ok) r.etat = et; } catch (e2) { if (!(e2 && e2.utilisateur)) throw e2; }
      }
      db.commit();
      return r;
    } catch (e) {
      if (e && e.utilisateur) return { ok: false, error: e.message };
      throw e;
    }
  }

  /* ---------- Données de départ ---------- */
  var BASES = [
    ["eco", "Économie", "#1461E0", "40"], ["droit", "Droit", "#0B7490", "40"], ["maths", "Mathématiques", "#7A3FD1", "60"],
    ["management", "Management", "#C2410C", "40"], ["espagnol", "Espagnol", "#B91C5C", "40"], ["francais", "Français", "#0F766E", "40"]
  ];
  /*LISTES*/ var LISTES = {}; /* les listes d'élèves sont dans le Google Sheet */ /*FIN_LISTES*/
  // codes : { admin, acces, "<id matière>": code }. Sans codes = démonstration (codes faciles).
  function depart(codes) {
    codes = codes || {};
    var info = "20 min de préparation, puis 20 min de passage";
    var lundiH = "12:00, 12:20, 12:40, 16:00, 16:20, 16:40", jeudiH = "08:00, 08:20, 08:40, 09:00, 17:00, 17:20";
    var src = function (id, matiere, jour, heures, debut) {
      return { id: id, matiere: matiere, jour: String(jour), heures: heures, frequence: "2", debut: debut, fin: "2027-05-28", salle: "", colleur: "" };
    };
    var classes = [{ id: "hec1", nom: "HEC1", code: "" }, { id: "hec2", nom: "HEC2", code: "" }];
    var eleves = [], matieres = [];
    classes.forEach(function (c) {
      (LISTES[c.id] || []).forEach(function (n) { eleves.push({ classe: c.id, nom: n, pin: "", echecs: "0" }); });
      BASES.forEach(function (b) {
        var id = b[0] + "-" + c.id;
        matieres.push({ id: id, classe: c.id, nom: b[1], couleur: b[2], duree: b[3], places: "2",
          info: c.id === "hec2" && (b[0] === "eco" || b[0] === "droit") ? info : b[0] === "francais" ? "Séances fixées au fil de l'année" : "",
          code: codes[id] || b[0] + (c.id === "hec1" ? "1" : "") });
      });
    });
    return {
      classes: classes, eleves: eleves, matieres: matieres,
      // Plannings connus. Les autres matières se saisissent dans l'espace gestion.
      regles: [
        src("r-eco-lun", "eco-hec2", 1, lundiH, "2026-09-21"),
        src("r-eco-jeu", "eco-hec2", 4, jeudiH, "2026-09-21"),
        src("r-droit-lun", "droit-hec2", 1, lundiH, "2026-09-28"),
        src("r-droit-jeu", "droit-hec2", 4, jeudiH, "2026-09-28")
      ],
      ponctuels: [], annulations: [], inscriptions: [], journal: [], ouvertures: [], archives: [],
      fermetures: FERME.map(function (f) { return { debut: f[0], fin: f[1], motif: f[2] }; }),
      reglages: [{ cle: "code_admin", valeur: codes.admin || "admin" }, { cle: "code_acces", valeur: codes.acces || "PREPA" }, { cle: "debut_annee", valeur: "2026-09-01" },
                 { cle: "ouverture_jours", valeur: "14" }, { cle: "ouverture_heure", valeur: "12:00" }]
    };
  }

  return {
    TABLES: TABLES, FERME: FERME, LYCEE: LYCEE, traiter: traiter, depart: depart, icsTexte: icsTexte,
    outils: { semaine: function (d) { return lundi(d); }, addDays: addDays, lundi: lundi, jourSemaine: jourSemaine, parseHeures: parseHeures, ferme: ferme, toMin: toMin, fromMin: fromMin, pad: pad }
  };
})();
if (typeof module !== "undefined") module.exports = COLLES;
