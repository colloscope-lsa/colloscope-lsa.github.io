#!/usr/bin/env python3
"""Assemble le site et le serveur à partir de src/.
   python3 build.py [URL_DU_SERVEUR]"""
import sys, json, os
here = os.path.dirname(os.path.abspath(__file__))
rd = lambda p: open(os.path.join(here, p), encoding="utf-8").read()
core, app, server = rd("src/core.js"), rd("src/app.html"), rd("src/server.gs")
url = sys.argv[1] if len(sys.argv) > 1 else ""
import re
SANS_LISTES = lambda c: re.sub(r"/\*LISTES\*/.*?/\*FIN_LISTES\*/", "var LISTES = {}; /* listes d'élèves : dans le Google Sheet */", c, flags=re.S)
core_public = SANS_LISTES(core) if url else core   # démo locale : listes gardées pour pouvoir tester
import base64
logo = lambda n: "data:image/png;base64," + base64.b64encode(open(os.path.join(here, "assets/logo-%d.png" % n), "rb").read()).decode()
app = app.replace("/*LOGO*/", logo(96))
body = app.replace("/*CORE*/", core)
os.makedirs(os.path.join(here, "site"), exist_ok=True)
head = """<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Colloscope">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="theme-color" content="#f7f8fa">
<link rel="icon" type="image/png" href="ICONE32">
<link rel="apple-touch-icon" href="ICONE180">
<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}</style>
ENTETE_APP
</head>
<body>
"""
# Titre et polices dans <head> pour le vrai site ; le reste de la page dans <body>
coupure = app.index("<style>")
head = head.replace("ICONE32", logo(32)).replace("ICONE180", logo(180)).replace("ENTETE_APP", app[:coupure].strip())
site = app[coupure:].replace("/*CORE*/", core_public).replace('API_URL: "",  /*API_URL*/', 'API_URL: ' + json.dumps(url) + ',')
open(os.path.join(here, "site/index.html"), "w", encoding="utf-8").write(head + site + "\n</body>\n</html>\n")
open(os.path.join(here, "apercu.html"), "w", encoding="utf-8").write(body)
open(os.path.join(here, "site/Code.gs"), "w", encoding="utf-8").write(
  "/* Colloscope — serveur. Collez TOUT ce fichier dans Extensions > Apps Script du Google Sheet. */\n\n" + SANS_LISTES(core) + "\n\n" + server)
print("ok", "serveur:", url or "(démonstration)")
